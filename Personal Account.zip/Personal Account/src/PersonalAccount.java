import java.util.ArrayList;

//First we'll create class Personal Account
public class PersonalAccount {
    private int accountNumber;
    private String accountHolder;
    private double balance;
    private ArrayList<Amount> transactions;

    //Then we'll create methods, which are written in instruction
    public PersonalAccount(int accountNumber, String accountHolder) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = 0.0;
    }
    //This method should add the deposit transaction to the "transactions" array and update the "balance".
    public void deposit(double amount){
        this.balance = this.balance + amount;
    }
    //This method should add the withdrawal transaction to the "transactions" array and update the "balance". Ensure that the withdrawal amount does not exceed the current balance.
    public void withdraw(double amount){
        if(balance >= amount){
            this.balance = this.balance - amount;
        }else{
            System.out.println("You don't have enough money!");
        }
    }
    //A method to print the transaction history (all transactions) of the account. Iterate through the "transactions" array and display each transaction, including the transaction type and amount.
    public void printTransactionHistory() {
        for (Amount transaction : transactions) {
            System.out.println(transaction);
        }
    }
    //A method to retrieve the current balance of the account.
    public double getBalance(){
        return balance;
     }
    //A method to retrieve the account number.
    public int getAccountNumber(){
        return accountNumber;
    }
    //A method to retrieve the account holder's name.
    public String getAccountHolder(){
        return accountHolder;
    }
}
