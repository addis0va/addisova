public class Main {
    public static void main(String[] args) {
        // Sample Usage
        PersonalAccount account = new PersonalAccount(301003, "Nurgul Adisova");
        account.deposit(7777.0);
        account.withdraw(777.0);
        account.deposit(5555.0);
        account.printTransactionHistory();
        System.out.println("Account Holder: " + account.getAccountHolder());
        System.out.println("Account Number: " + account.getAccountNumber());
        System.out.println("Account Balance:" + account.getBalance());
    }
}
